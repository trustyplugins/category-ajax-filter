<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
class CAF_shortcode_render
{
    public function __construct()
    {
        add_shortcode("caf_filter", array($this, "caf_filter_call"));
        add_filter('tc_caf_post_layout_read_more', array($this, 'tc_caf_post_layout_read_more'), 5, 2);
    }
    public function tc_caf_post_layout_read_more($text, $id)
    {
        $text = __('Read More', 'category-ajax-filter');
        return $text;
    }
    public function caf_filter_call($atts)
    {
        $atts = shortcode_atts(
            array(
                'id' => '',
            ),
            $atts
        );
        $id = isset( $atts['id'] ) ? $atts['id'] : '';

        if ( '' === $id ) {
            return "<div class='error-of-missing-id error-caf'>" . esc_html__('Nothing Found, Missing id as an argument.', 'category-ajax-filter') . ' <a href="https://caf.trustyplugins.com/docs/documentation/getting-started/" target="_blank">' . esc_html__('See Documentation', 'category-ajax-filter') . "</a></div>";
        }

        if ( class_exists( 'CAF_Builder_Tier' ) && ! CAF_Builder_Tier::reserve_page_filter_instance() ) {
            return CAF_Builder_Tier::get_multiple_filters_per_page_message();
        }

        if ( class_exists( 'CAF_Builder_Frontend' ) && CAF_Builder_Frontend::instance()->is_builder_shortcode_id( $id ) ) {
            return CAF_Builder_Frontend::instance()->render_shortcode( $id );
        }

        ob_start();
        if (class_exists('TC_CAF_PRO')) {
         $caf_pro_class=new TC_CAF_PRO();
         if($caf_pro_class->check_license()=='Deactivated') {
            echo "<center style='color:red'>Error : CAF PRO's license is not activated. Please activate the license from admin panel or deactivate the PRO version.</center>";
            $output = ob_get_contents();
            ob_end_clean();
            return $output;
         }
        }
        else {

        $caf_filter = new CAF_front_filter();
        static $b = 1;
        $id = $atts['id'];
        if (!get_post_meta($id, 'caf_taxonomy')) {
            return "<h2 style='background: #333348;color: #fff;font-size: 14px;line-height: 18px;padding: 10px;margin: 0;width: 100%;display: inline-block;text-align: center;border: none;text-shadow: none;box-shadow: none;'>" . esc_html__('Please select Taxonomy from specific CAF Filter. It is required to properly work for your Filter.', 'category-ajax-filter') . "</h2>";
        }
        if (!get_post_meta($id, 'caf_terms')) {
            return "<h2 style='background: #333348;color: #fff;font-size: 14px;line-height: 18px;padding: 10px;margin: 0;width: 100%;display: inline-block;text-align: center;border: none;text-shadow: none;box-shadow: none;'>" . esc_html__('Please select Categories/Terms from specific CAF Filter. It is required to properly work for your Filter.', 'category-ajax-filter') . "</h2>";
        }
        include TC_CAF_PATH . 'includes/front-variables.php';
        if (get_post_meta($id, 'caf_cpt_value')) {
            $caf_cpt_value = get_post_meta($id, 'caf_cpt_value', true);
        }
        $pt = get_post_type($id);
        wp_enqueue_script("jquery");
        wp_enqueue_script('tc-caf-frontend-scripts');
        $post_style = ("tc-caf-" . $caf_post_layout);
        $filter_style = ("tc-caf-" . $caf_filter_layout);
        wp_enqueue_style('tc-caf-common-style');
        wp_enqueue_style($filter_style);
        wp_enqueue_style($post_style);
        wp_enqueue_style('tc-caf-font-awesome-style');
        $handle = "tc-caf-dynamic-style-" . $caf_filter_layout;
        wp_enqueue_style($handle, TC_CAF_URL . '/assets/css/dynamic-styles.css', '', TC_CAF_PLUGIN_VERSION);
        setDynamicFilterCssFree($id, $handle, $caf_filter_layout, $b, 'shortcode');
        if (($id && !empty($id) && get_post_type($id) == 'caf_posts')) {
            if ($caf_filter_layout == 'filter-layout3') {$cl = 'sidebar';} else { $cl = '';}
            //var_dump($tax);
            if (is_array($tax)) {
                $tax = implode(",", $tax);
            }
            //var_dump($tax);
            echo '<div id="caf-post-layout-container" class="caf-post-layout-container ' . esc_attr($cl) . ' ' . esc_attr($caf_filter_layout) . ' ' . esc_attr($caf_post_layout) . ' data-target-div' . esc_attr($b) . '" data-post-type="' . esc_attr($caf_cpt_value) . '" data-tax="' . esc_attr($tax) . '" data-terms="' . esc_attr($trm) . '" data-per-page="' . esc_attr($caf_per_page) . '" data-selected-terms="' . esc_attr($trm) . '" data-filter-id="' . esc_attr($id) . '" data-post-layout="' . esc_attr($caf_post_layout) . '" data-target-div="data-target-div' . esc_attr($b) . '">';
            if ($caf_filter_status == 'on') {
                if ($caf_filter_layout && strlen($caf_filter_layout) > 13) {
                    $filepath = TC_CAF_PATH . "includes/layouts/filter/" . $caf_filter_layout . ".php";
                    if (file_exists($filepath)) {
                        include $filepath;
                    } else {
                        echo "<div class='error-of-filter-layout error-caf'>" . esc_html('Filter Layout is not Available.', 'category-ajax-filter') . "</div>";
                    }
                }
            }
            setDynamicFilterCssFree($id, $handle, $caf_post_layout, $b, 'shortcode');
            echo "<div id='manage-ajax-response' class='caf-row'>";
            if ($caf_post_layout && strlen($caf_post_layout) > 11) {
                echo '<div class="status"><i class="fa fa-spinner" aria-hidden="true"></i></div>';
                echo '<div class="content"></div>';
            }
            echo "</div>";
            echo "</div>";
        } else {
            if (empty($id)) {
                echo "<div class='error-of-missing-id error-caf'>" . esc_html__('Nothing Found, Missing id as an argument.', 'category-ajax-filter') . ' <a href="https://caf.trustyplugins.com/docs/documentation/getting-started/" target="_blank">' . esc_html__('See Documentation', 'category-ajax-filter') . "</a></div>";
            } else {
                echo "<div class='error-of-missing-id error-caf'>" . esc_html__('Nothing Found, ID Mismatched.', 'category-ajax-filter') . ' <a href="https://caf.trustyplugins.com/docs/documentation/getting-started/" target="_blank">' . esc_html__('See Documentation', 'category-ajax-filter') . "</a></div>";
            }
        }
        $output = ob_get_contents();
        ob_end_clean();
        $b++;
        return $output;
    }
}

    
}
class CAF_get_filter_posts
{
    public function __construct()
    {
        add_action('wp_ajax_get_filter_posts', array($this, 'get_filter_posts'));
        add_action('wp_ajax_nopriv_get_filter_posts', array($this, 'get_filter_posts'));
    }
    public function get_filter_posts()
    {
        check_ajax_referer('tc_caf_ajax_nonce', 'nonce');

        $response = [
            'status' => 500,
            'message' => 'Something is wrong, please try again later ...',
            'content' => false,
            'found' => 0,
        ];

        $params = (isset($_POST['params']) && is_array($_POST['params'])) ? wp_unslash($_POST['params']) : array();
        $filter_id = isset($params['filter-id']) ? absint($params['filter-id']) : 0;

        if (!$filter_id || get_post_type($filter_id) !== 'caf_posts') {
            $response['status'] = 403;
            $response['message'] = 'Invalid filter';
            die(wp_json_encode($response));
        }

        // Trusted settings from filter meta (do not trust client CPT/tax/per-page/layout).
        $post_type = sanitize_key((string) get_post_meta($filter_id, 'caf_cpt_value', true));
        $tax = sanitize_key((string) get_post_meta($filter_id, 'caf_taxonomy', true));
        $allowed_terms = get_post_meta($filter_id, 'caf_terms', true);
        if (!is_array($allowed_terms)) {
            $allowed_terms = array();
        }
        $allowed_terms = array_values(array_filter(array_map('absint', $allowed_terms)));

        if (empty($post_type) || empty($tax) || empty($allowed_terms)) {
            $response['status'] = 501;
            $response['message'] = 'Filter is not configured';
            die(wp_json_encode($response));
        }

        $per_page = (int) get_post_meta($filter_id, 'caf_per_page', true);
        if ($per_page === -1 || $per_page < 1) {
            $per_page = 5;
        }
        if ($per_page > 100) {
            $per_page = 100;
        }

        $caf_post_layout = sanitize_file_name((string) get_post_meta($filter_id, 'caf_post_layout', true));
        $allowed_layouts = array('post-layout1', 'post-layout2', 'post-layout3', 'post-layout4');
        /**
         * Filter allowed post layout slugs for AJAX includes.
         *
         * @param string[] $allowed_layouts Layout slugs.
         * @param int      $filter_id       Filter post ID.
         */
        $allowed_layouts = apply_filters('tc_caf_allowed_post_layouts', $allowed_layouts, $filter_id);
        if (!in_array($caf_post_layout, $allowed_layouts, true)) {
            $caf_post_layout = 'post-layout1';
        }

        // Soft-trusted client inputs: page + selected terms only.
        $page = isset($params['page']) ? max(1, absint($params['page'])) : 1;
        $term_raw = isset($params['term']) ? sanitize_text_field($params['term']) : '';
        $target_div = isset($params['data-target-div']) ? sanitize_text_field($params['data-target-div']) : '';

        if ($term_raw === '' || strtolower($term_raw) === 'all') {
            $terms = $allowed_terms;
        } else {
            $requested = array_filter(array_map('absint', explode(',', $term_raw)));
            $terms = array_values(array_intersect($requested, $allowed_terms));
            if (empty($terms)) {
                $response = [
                    'status' => 501,
                    'message' => 'Term doesn\'t exist',
                    'content' => 0,
                ];
                die(wp_json_encode($response));
            }
        }

        $tax_qry = [
            [
                'taxonomy' => $tax,
                'field' => 'term_id',
                'terms' => $terms,
                'operator' => 'IN',
            ],
        ];

        $default_order_by = 'title';
        if (get_post_meta($filter_id, 'caf_post_orders_by', true)) {
            $default_order_by = get_post_meta($filter_id, 'caf_post_orders_by', true);
        }
        $default_order_by = apply_filters('tc_caf_filter_posts_order_by', $default_order_by);

        $default_order = 'asc';
        if (get_post_meta($filter_id, 'caf_post_order_type', true)) {
            $default_order = get_post_meta($filter_id, 'caf_post_order_type', true);
        }
        $default_order = apply_filters('tc_caf_filter_posts_order', $default_order);

        $args = [
            'paged' => $page,
            'post_type' => $post_type,
            'post_status' => 'publish',
            'posts_per_page' => $per_page,
            // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_tax_query
            'tax_query' => $tax_qry,
            'orderby' => $default_order_by,
            'order' => $default_order,
        ];
        $qry = new WP_Query($args);

        ob_start();
        echo '<div class="status"></div>';
        $filepath = TC_CAF_PATH . 'includes/layouts/post/' . $caf_post_layout . '.php';
        if (file_exists($filepath)) {
            include $filepath;
        } else {
            echo "<div class='error-of-post-layout error-caf'>" . esc_html__('Post Layout is not Available.', 'category-ajax-filter') . '</div>';
            $response = [
                'status' => 404,
                'message' => 'No posts found',
            ];
        }

        $response['content'] = ob_get_clean();
        die(wp_json_encode($response));
    }
}

class CAF_content_length
{
    public $caf_post_id, $words;
    public function get_caf_content($caf_post_id)
    {
        $content = get_the_content();
        $content = preg_replace('#\[[^\]]+\]#', '', $content);
        $content = wp_trim_words($content, '40');
        return $content;
    }

    public function get_caf_content2($caf_post_id, $words)
    {
        $content = get_the_content();
        $content = preg_replace('#\[[^\]]+\]#', '', $content);
        $content = wp_trim_words($content, $words);
        return $content;
    }
}

class CAF_front_filter
{
    public function __construct()
    {

        add_filter('tc_caf_add_custom_list_before_filter', array($this, 'tc_caf_add_custom_list_before_filter'), 5);
        add_filter('tc_caf_add_custom_span_before_filter', array($this, 'tc_caf_add_custom_span_before_filter'), 5);
        add_filter('tc_caf_custom_title_before_sidebar_filter', array($this, 'tc_caf_custom_title_before_sidebar_filter'), 5);
        add_filter('tc_caf_filter_order_by', array($this, 'tc_caf_filter_order_by'), 5, 1);
        add_filter('tc_caf_filter_all_text', array($this, 'tc_caf_filter_all_text'), 5, 1);
        add_filter('tc_caf_filter_posts_order_by', array($this, 'tc_caf_filter_posts_order_by'), 5, 1);
        add_filter('tc_caf_filter_posts_order', array($this, 'tc_caf_filter_posts_order'), 5, 1);
    }

    public function tc_caf_add_custom_span_before_filter()
    {
        return esc_html__('I want to check out ', 'category-ajax-filter');
    }
    public function tc_caf_add_custom_list_before_filter()
    {
        return esc_html__('Everything', 'category-ajax-filter');
    }
    public function tc_caf_custom_title_before_sidebar_filter()
    {
        return esc_html_e('Categories', 'category-ajax-filter');

    }
    public function tc_caf_filter_order_by($terms_sel)
    {
        return $terms_sel;
    }
    public function tc_caf_filter_posts_order_by($default)
    {
        return 'title';
    }
    public function tc_caf_filter_posts_order($default)
    {
        return 'asc';
    }
    public function tc_caf_filter_all_text($all_text)
    {
         return __('All', 'category-ajax-filter');
    }
}
class CAF_ajax_pagination
{
    public function caf_ajax_pager($query, $paged, $caf_post_layout, $caf_pagi_type, $filter_id)
    {
        //echo $caf_pagi_type;
        // $filter_id
        if (class_exists("TC_CAF_PRO")) {
            $caf_pagination_status = 'on';
            if (get_post_meta($filter_id, 'caf_pagination_status')) {
                $caf_pagination_status = get_post_meta($filter_id, 'caf_pagination_status', true);
            }
            if ($caf_pagination_status == "off") {
                return;
            }
        }
        if ($caf_pagi_type == 'number') {
            $this->caf_number_pagination($query, $paged, $caf_post_layout, $caf_pagi_type, $filter_id);
        } else {
            if (class_exists("TC_CAF_PRO")) {
                include TC_CAF_PRO_PATH . "includes/pagination.php";
            } else {
                $this->caf_number_pagination($query, $paged, $caf_post_layout, $caf_pagi_type, $filter_id);
            }
        }
    }
    public function caf_number_pagination($query, $paged, $caf_post_layout, $caf_pagi_type, $filter_id)
    {
        if (!$query) {
            return;
        }

        $prev_text = 'Prev';
        $next_text = 'Next';
        $prev_text = apply_filters('tc_caf_filter_prev_text', $prev_text, $filter_id);
        $next_text = apply_filters('tc_caf_filter_next_text', $next_text, $filter_id);

        $paginate = paginate_links([
            'base' => '%_%',
            'type' => 'array',
            'total' => $query->max_num_pages,
            'format' => '#page=%#%',
            'current' => max(1, $paged),
            'prev_text' => $prev_text,
            'next_text' => $next_text,
        ]);
        if ($query->max_num_pages > 1): ?>
        <ul id="caf-layout-pagination" class="caf-pagination <?php echo esc_attr($caf_post_layout); ?>">
            <?php foreach ($paginate as $page): ?>
                <li><?php echo wp_kses_post($page); ?></li>
            <?php endforeach;?>
        </ul>
    <?php endif;
    }
}
new CAF_get_filter_posts();
if (class_exists("TC_CAF_PRO")) {
    if (!defined('TC_CAF_PRO_PATH')) {
    $caf_pr=new TC_CAF_PRO();
    $caf_pr->tc_caf_plugin_constants();
    if(file_exists(TC_CAF_PRO_PATH.'/admin/post-class.php')) {
   include TC_CAF_PRO_PATH.'/admin/post-class.php';
    }
}
else {
    if(file_exists(TC_CAF_PRO_PATH.'/admin/post-class.php')) {
        include TC_CAF_PRO_PATH.'/admin/post-class.php';
         }
}
    }
    else {
        //echo "no";
        include TC_CAF_PATH.'/includes/post-class.php';
    }